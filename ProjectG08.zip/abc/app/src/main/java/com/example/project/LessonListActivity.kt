package com.example.project

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.project.adapters.LessonAdapter
import com.example.project.models.Lesson

class LessonListActivity : AppCompatActivity(), LessonAdapter.OnItemClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var lessonAdapter: LessonAdapter
    private lateinit var lessons: MutableList<Lesson>
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lesson_list)

        sharedPreferences = getSharedPreferences("LessonPreferences", Context.MODE_PRIVATE)

        recyclerView = findViewById(R.id.lessonRecyclerView)
        lessons = getDummyLessons().toMutableList()
        loadLessonStatuses() // Load lesson statuses from SharedPreferences
        lessonAdapter = LessonAdapter(lessons, this)
        recyclerView.adapter = lessonAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun loadLessonStatuses() {
        for (i in 0 until lessons.size) {
            val completed = sharedPreferences.getBoolean("lesson_${i}_completed", false)
            lessons[i].completed = completed
        }
    }
    private fun resetLessonStatuses() {
        val editor = sharedPreferences.edit()
        for (i in 0 until lessons.size) {
            editor.putBoolean("lesson_${i}_completed", false)
        }
        editor.apply()
        lessonAdapter.notifyDataSetChanged()
    }

    private fun saveLessonStatus(position: Int) {
        val lesson = lessons[position]
        val editor = sharedPreferences.edit()
        editor.putBoolean("lesson_${position}_completed", lesson.completed)
        editor.apply()
    }

    private fun getDummyLessons(): List<Lesson> {
        val lessons = mutableListOf<Lesson>()

        lessons.add(
            Lesson(
                number = 1,
                name = "Introduction to Programming",
                length = "30 mins",
                description = "This lesson covers the basics of programming.",
                completed = false,
                hasVideo = true,
                videoLink = "https://www.youtube.com/watch?v=PFVKjUUZMf8&t=9s&ab_channel=Simplilearn"
            )
        )
        lessons.add(
            Lesson(
                number = 2,
                name = "Introduction to OOP",
                length = "30 mins",
                description = "This lesson covers the basics of programming.",
                completed = false,
                hasVideo = true,
                videoLink = "https://www.youtube.com/watch?v=PFVKjUUZMf8&t=9s&ab_channel=Simplilearn"
            )
        )
        lessons.add(
            Lesson(
                number = 3,
                name = "Introduction to Kotlin",
                length = "70 mins",
                description = "This lesson covers the basics of programming.",
                completed = false,
                hasVideo = true,
                videoLink = "https://www.youtube.com/watch?v=PFVKjUUZMf8&t=9s&ab_channel=Simplilearn"
            )
        )
        lessons.add(
            Lesson(
                number = 4,
                name = "Introduction to Python",
                length = "30 mins",
                description = "This lesson covers the basics of programming.",
                completed = false,
                hasVideo = true,
                videoLink = "https://www.youtube.com/watch?v=PFVKjUUZMf8&t=9s&ab_channel=Simplilearn"
            )
        )
        lessons.add(
            Lesson(
                number = 5,
                name = "Introduction to Java",
                length = "50 mins",
                description = "This lesson covers the basics of programming.",
                completed = false,
                hasVideo = true,
                videoLink = "https://www.youtube.com/watch?v=PFVKjUUZMf8&t=9s&ab_channel=Simplilearn"
            )
        )
        return lessons
    }

    override fun onItemClick(position: Int) {
        val lesson = lessons[position]
        val intent = Intent(this, LessonDetailsActivity::class.java)
        intent.putExtra("lesson", lesson)
        startActivityForResult(intent, LESSON_DETAILS_REQUEST)
    }

    override fun onMarkCompleteClick(position: Int) {
        val lesson = lessons[position]
        lesson.completed = true
        lessons[position] = lesson  // Update the lesson in the list
        lessonAdapter.notifyItemChanged(position) // Notify adapter of the change
        saveLessonStatus(position) // Save updated lesson status
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == LESSON_DETAILS_REQUEST && resultCode == Activity.RESULT_OK) {
            val lesson = data?.getSerializableExtra("lesson") as Lesson
            val position = lessons.indexOfFirst { it.number == lesson.number }
            if (position != -1) {
                lessons[position] = lesson  // Update the lesson in the list
                lessonAdapter.notifyItemChanged(position) // Notify adapter of the change
                saveLessonStatus(position) // Save updated lesson status
            }
        }
    }
    override fun onResume() {
        resetLessonStatuses()
        super.onResume()
    }
    companion object {
        const val LESSON_DETAILS_REQUEST = 1001
    }
}