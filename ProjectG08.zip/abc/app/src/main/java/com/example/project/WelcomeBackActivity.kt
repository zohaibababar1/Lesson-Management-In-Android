package com.example.project

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class WelcomeBackActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_back)

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        val userName = sharedPreferences.getString("user_name", "Default Name")
        val welcomeTextView = findViewById<TextView>(R.id.welcomeTextView)
        welcomeTextView.text = "Welcome back, $userName!"

        val proceedButton = findViewById<Button>(R.id.proceedButton)
        val resetButton = findViewById<Button>(R.id.resetButton)

        proceedButton.setOnClickListener {
            startActivity(Intent(this, LessonListActivity::class.java))
            finish()
        }

        resetButton.setOnClickListener {
            resetData()
            startActivity(Intent(this, EnterNameActivity::class.java))
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            finish()
        }
    }

    private fun resetData() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }
}