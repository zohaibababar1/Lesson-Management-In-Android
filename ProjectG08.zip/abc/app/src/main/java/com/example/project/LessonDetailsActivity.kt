package com.example.project

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.example.project.models.Lesson

class LessonDetailsActivity : AppCompatActivity() {

    private lateinit var lesson: Lesson

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lesson_details)

        lesson = intent.getSerializableExtra("lesson") as Lesson

        val markCompleteButton: Button = findViewById(R.id.markCompleteButton)
        markCompleteButton.setOnClickListener {
            markLessonCompleted()
        }

        val watchLessonButton: Button = findViewById(R.id.watchLessonButton)
        watchLessonButton.setOnClickListener {
            watchLesson()
        }
    }

    private fun markLessonCompleted() {
        lesson.completed = true
        setResult(Activity.RESULT_OK, Intent().apply {
            putExtra("lesson", lesson)
        })
        finish()
    }

    private fun watchLesson() {
        val videoUri = Uri.parse(lesson.videoLink)
        val intent = Intent(Intent.ACTION_VIEW, videoUri)
        startActivity(intent)
    }
}