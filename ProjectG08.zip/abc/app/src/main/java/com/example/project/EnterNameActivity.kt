package com.example.project

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class EnterNameActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_name)

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        val continueButton = findViewById<Button>(R.id.continueButton)
        val enterNameEditText = findViewById<EditText>(R.id.enterNameEditText)

        continueButton.setOnClickListener {
            val enteredName = enterNameEditText.text.toString()
            saveName(enteredName)
            startActivity(Intent(this, LessonListActivity::class.java))
            finish()
        }
    }

    private fun saveName(name: String) {
        val editor = sharedPreferences.edit()
        editor.putString("user_name", name)
        editor.putBoolean("first_time", false)
        editor.apply()
    }
}